#! /bin/bash
for i in 1 2 3 4 5
do
	echo "The value of i is $i"
done
