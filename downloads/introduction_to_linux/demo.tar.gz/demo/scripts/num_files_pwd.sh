#! /bin/bash
echo "Number of files in $(pwd) is $(find -type f | wc -l)."
echo "There are also $(find -type d -not -name . | wc -l) directories".
