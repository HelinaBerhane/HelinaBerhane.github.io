#! /bin/bash
echo "Script beginning in $(pwd)"
sleep 3
echo "Script finished"
