#! /bin/bash
echo "Running $0 with argument '$1'"
echo "Number of files in $(pwd) is $(find $1 -type f | wc -l)."
echo "There are also $(find $1 -type d -not -name . | wc -l) directories".
