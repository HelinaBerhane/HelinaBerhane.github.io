#! /bin/bash
echo "Here are the arguments I received:"
for arg in $@
do
	echo "\"$arg\""
done
