#! /bin/bash
for name in world sailor stranger $USER "Barrack Obama" you
do
	echo "Hello, $name!"
done
