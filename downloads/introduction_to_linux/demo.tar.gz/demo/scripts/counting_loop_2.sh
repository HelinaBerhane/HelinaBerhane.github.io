#! /bin/bash
for i in $(seq 3 4 20)
do
	echo "The value of i is $i"
done
