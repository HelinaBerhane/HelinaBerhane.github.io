#! /bin/bash
for tex_file in *.tex
do
	echo -n "Compiling $tex_file... "
	pdflatex -interaction=batchmode -synctex=1 $tex_file > /dev/null
	if [ $? -eq 0 ]
	then
		echo "✓"
	else
		echo "✗"
	fi
done
