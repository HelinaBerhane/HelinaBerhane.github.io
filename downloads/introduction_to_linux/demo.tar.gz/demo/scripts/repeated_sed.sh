#! /bin/bash
echo "This text file contains the letter 't'." > example.file
sed -i "s/t/tt/g" example.file
sed -i "s/t/tt/g" example.file
sed -i "s/t/tt/g" example.file
echo "The result is '$(cat example.file)'."
