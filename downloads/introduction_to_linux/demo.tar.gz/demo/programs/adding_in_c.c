#include <stdio.h>

int main(){
	float a = 0.1;
	float b = 0.2;
	printf("0.1 + 0.2 = %1.16f\n", a + b);
	return 0;
}
