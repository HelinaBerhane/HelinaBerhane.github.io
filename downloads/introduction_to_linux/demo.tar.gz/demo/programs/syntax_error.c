#include <stdio.h>

int main(){
	int a, b = 2
	int c = "blah blah blah;	
	printf("2 + 2 = %i\n", a + b);
	return 0;
}
