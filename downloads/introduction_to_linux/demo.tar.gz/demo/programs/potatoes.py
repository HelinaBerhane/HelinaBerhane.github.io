#! /usr/bin/env python3
import time
ticks = 0

with open('potatoes.log', 'wt') as f:
	while True:
		time.sleep(1)
		ticks += 1
		print('ticks')
		if ticks % 4 != 0:
			print("{} potato,".format(ticks), file=f)
		else:
			print("More!\n", file=f)
