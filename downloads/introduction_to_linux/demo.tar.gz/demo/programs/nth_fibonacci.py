#! /usr/bin/env python3
from sys import argv

def fib():
	prev = 1;
	curr = 1;
	
	yield 1;
	yield 1;
	
	while True:
		prev, curr = curr, prev + curr
		yield curr

def get_nth(generator, n):
	for i in range(n):
		ans = next(generator)
	return ans

if __name__ == "__main__":
	#This is too succinct and is naughty
	ans = get_nth( fib(), int(argv[1]) )
	try:
		display = argv[2].lower().strip() == "print"
	except Exception:
		display = False
	if display:
		print(ans)
