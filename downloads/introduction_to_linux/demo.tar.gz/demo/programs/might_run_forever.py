#! /usr/bin/env python3
import time
from random import random, randrange

def sleep_for(duration):
	list = []
	seconds = 0
	while seconds < duration:
		for i in range(500):
			list.append(random())
		time.sleep(1)
		seconds += 1
		if seconds % 5 == 0:
			print("I have been running for {} iterations.".format(seconds))
	
if __name__ == "__main__":
	if random() < 0.4:
		sleep_for(float('inf'))
	else:
		sleep_for(randrange(20, 180))
