#! /usr/bin/env python3
import sys

try:
	name = sys.argv[1]
except IndexError:
	name = "world"

print("Hello, {}!".format(name))
