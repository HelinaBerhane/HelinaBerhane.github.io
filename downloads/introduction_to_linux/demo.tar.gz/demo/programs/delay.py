#! /usr/bin/env python3
from time import sleep
import sys

def main():
	arg = None
	try:
		arg = sys.argv[1]
	except IndexError:
		print("Please provide the number of seconds to sleep for.")
		return
		
	try:
		delay = float(arg)
	except ValueError:
		print("Couldn't interpret first argument as a number.")
		return
	
	sleep(delay)
	print("Wakey wakey! I slept for {} seconds.".format(delay))

if __name__ == "__main__":
	main()
