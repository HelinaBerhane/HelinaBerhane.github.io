#! /usr/bin/env python3
import time
seconds = 0
while True:
	time.sleep(1)
	seconds += 1
	if seconds % 5 == 0:
		print("I have been running for {} seconds.".format(seconds))
	
	
